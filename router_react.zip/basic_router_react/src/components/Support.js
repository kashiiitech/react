import React from 'react';

const Support = () => {
    return(
        <div>
            This is support page
        </div>
    )
}

export default Support;